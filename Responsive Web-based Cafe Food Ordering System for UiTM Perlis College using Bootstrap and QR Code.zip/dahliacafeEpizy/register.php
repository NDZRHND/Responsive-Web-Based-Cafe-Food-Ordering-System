<?php
session_start();

if(isset($_SESSION['auth']))
{
    if(!isset($_SESSION['message'])){
        $_SESSION['message'] = "You are already logged In";
    }
    header("Location: index.php");
    exit(0);
}
include('admin/config/dbcon.php');
include('includes/header.php');
?>


<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5">
                <div class="wrap">
                    <div class="img" style="background-image: url(assets/img/sign_in.jpg);"></div>
                    <div class="login-wrap p-4 p-md-5">
                        <div class="d-flex">
                            <div class="w-100">
                            <h3 class="mb-4">Register Here</h3>
                            </div>		
                        </div>

                        <form action="registercode.php" method="POST" class="register-form">
                            <div class="form-group">
                            <input name="fname" type="text" class="form-control" required>
                            <label class="form-control-placeholder" for="fname">First Name</label>
                            </div> 

                            <div class="form-group">
                            <input name="lname" type="text" class="form-control" required>
                            <label class="form-control-placeholder" for="lname">Last Name</label>
                            </div> 

                            <div class="form-group">
                            <input name="email" type="email"  class="form-control" required>
                            <label class="form-control-placeholder" for="email">Email</label>
                            </div>

                            <div class="form-group">
                            <input name="pnum" type="tel" class="form-control" required>
                            <label class="form-control-placeholder" for="pnum">Phone Number</label>
                            </div>

                            <div class="form-group ">
                            <input name="password" type="password" class="form-control"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                            <label class="form-control-placeholder" for="password" required>Password</label>
                            </div>
                
                            <div class="form-group ">
                            <input name="conpassword" type="password" class="form-control" required>
                            <label class="form-control-placeholder" for="conpassword"  required>Confirm Password</label>
                            </div>

                            <div class="form-group">
                            <select class="form-control" aria-label="Select" name="user_type" required>
                                <option disabled selected>Choose Your Role</option>
                                <option value="manager">Manager</option>
                                <option value="admin">Admin (Staff)</option>
                                <option value="kitchen">Kitchen Crew (Staff)</option>
                                <option value="cashier">Cashier (Staff)</option>
                                <option value="user">Customer</option>
                            </select>
                            </div>

                            <div class="form-group">
                            <input type="submit" name="submit" value="Register" class="form-control btn btn-primary rounded submit px-3">
                            </div>  

                        </form>
                        <p class="text-center">Already have an account? <a data-toggle="tab" href="login.php">Sign In</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
include('includes/footer.php');
?>

<script>
      var myInput = document.getElementById("password");
      var letter = document.getElementById("letter");
      var capital = document.getElementById("capital");
      var number = document.getElementById("number");
      var length = document.getElementById("length");

      // When the user clicks on the password field, show the message box
      myInput.onfocus = function() {
        document.getElementById("message").style.display = "block";
      }

      // When the user clicks outside of the password field, hide the message box
      myInput.onblur = function() {
        document.getElementById("message").style.display = "none";
      }

      // When the user starts to type something inside the password field
      myInput.onkeyup = function() {
        // Validate lowercase letters
        var lowerCaseLetters = /[a-z]/g;
        if(myInput.value.match(lowerCaseLetters)) {  
          letter.classList.remove("invalid");
          letter.classList.add("valid");
        } else {
          letter.classList.remove("valid");
          letter.classList.add("invalid");
        }
        
        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if(myInput.value.match(upperCaseLetters)) {  
          capital.classList.remove("invalid");
          capital.classList.add("valid");
        } else {
          capital.classList.remove("valid");
          capital.classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if(myInput.value.match(numbers)) {  
          number.classList.remove("invalid");
          number.classList.add("valid");
        } else {
          number.classList.remove("valid");
          number.classList.add("invalid");
        }
        
        // Validate length
        if(myInput.value.length >= 8) {
          length.classList.remove("invalid");
          length.classList.add("valid");
        } else {
          length.classList.remove("valid");
          length.classList.add("invalid");
        }
      }
    </script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    
  function PhoneNumvalidate()
  {
    var filter = /^[0-9][0-9]{9}$/; //PATTERN FOR MOBILE NUMBER
    
    var a = $(".phone").val();     
    if (!(filter.test(a))) {
        swal("","Enter valid mobile number","warning");
        $(".phone").val('');
    }
  }

</script>
