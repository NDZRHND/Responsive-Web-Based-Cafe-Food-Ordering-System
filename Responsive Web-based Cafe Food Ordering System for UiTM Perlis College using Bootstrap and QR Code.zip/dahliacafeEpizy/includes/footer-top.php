<div class="footer-area">
    <div class="container">
      <div class="row">

        <div class="col-md-3">
          <h4 class="footer-heading">Operation Hours</h4>
          <div class="underline"></div>
            <div class="footer-link">
            <div>
                <a href="#">Monday - Sunday</a><br>
                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 3:00 PM - 10:00 PM</a>
            </div>

          </div>
          
        </div>

        <div class="col-md-3">
          <h4 class="footer-heading">Quick Links</h4>
          <div class="underline"></div>
          <div class="footer-link">
            <div>
              <a href="index.php"> <i class="fa fa-angle-right"></i> Home</a>
            </div>
            <div>
              <a href="about-us.php"> <i class="fa fa-angle-right"></i> About Us</a>
            </div>
            <div>
              <a href="cart.php"> <i class="fa fa-angle-right"></i> My Cart</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <h4 class="footer-heading">Links</h4>
          <div class="underline"></div>
          <div class="footer-link">
            <div>
              <a href="login.php"> <i class="fa fa-angle-right"></i> Login</a>
            </div>
            <div>
              <a href="register.php"> <i class="fa fa-angle-right"></i> Register</a>
            </div>
            <div>
              <a href="myorders.php"> <i class="fa fa-angle-right"></i> My Orders</a>
            </div>
            <div>
              <a href="myprofile.php"> <i class="fa fa-angle-right"></i> My Profile</a>
            </div>
            <div>
              <a href="https://forms.gle/8fHur269gVdx7uZBA"> <i class="fa fa-angle-right"></i> UAT Survey</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <h4 class="footer-heading">Contact Information</h4>
          <div class="underline"></div>
          <div class="footer-link">
            <div>
              <a href="#"> <i class="fa fa-map-marker"></i>
              Kafeteria Dahlia 2<br>
              Universiti Teknologi Mara<br>
              Cawangan Arau, 02000 Perlis <br><br></a>
            </div>
            <div>
              <a href="#"> <i class="fa fa-phone"></i> +601 352 163 55</a>
            </div>
            <div>
              <a href="#"> <i class="fa fa-envelope"></i> dahlia@uitmperlis.com</a>
            </div>
            <div>
              <a href="#"> <i class="fa fa-envelope"></i> dahlia@uitmperlis.com</a>
            </div>
          </div>
        </div>
        <div class="col-md-12 text-center">
          <hr class="bg-yellow">
          <p class="text-white f-12">
            &copy; Copyright at Dahlia Cafeteria. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
</div>
