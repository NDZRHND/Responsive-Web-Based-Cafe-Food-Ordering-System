<?php
session_start();

if(isset($_SESSION['auth']))
{
    if(!isset($_SESSION['message'])){
        $_SESSION['message'] = "You are already logged In";
    }
    header("Location: index.php");
    exit(0);
}
include('admin/config/dbcon.php');
include('includes/header.php');
?>

<div class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
				<div class="col-md-7 col-lg-5">

					<div class="wrap">
						<div class="img" style="background-image: url(assets/img/sign_in.jpg);"></div>
						<div class="login-wrap p-4 p-md-5">

							<div class="d-flex">
								<div class="w-100">
								<h4 " class="mb-4">Sign In</h4>
								</div>		
							</div>

							<form  action="logincode.php" method="POST" class="signin-form" >
								<?php
									if(isset($error)){
									foreach($error as $error){
										echo '<span class="error-msg">'.$error.'</span>';
										};
									};
								?>
								<div class="form-group">
									<input name="email" type="email"  class="form-control" required>
									<label class="form-control-placeholder" for="email">Email</label>
								</div>

								<div class="form-group ">
									<input name="password" type="password" class="form-control" required>
									<label class="form-control-placeholder" for="password">Password</label>
								</div>
								

								<div class="form-group">
									<input type="submit" name="login" value="Login" class="form-control btn btn-primary rounded submit px-3">
								</div>
							</form>
							<p class="text-center">Register an account <a data-toggle="tab" href="register.php">Sign Up</a></p>	
						</div>
		      		</div>
				</div>
            </div>
    </div>
</div>

<?php
include('includes/footer.php');
?>