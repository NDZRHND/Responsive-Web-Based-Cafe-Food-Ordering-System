<?php
session_start();
include('admin/config/dbcon.php');

if(isset($_POST['submit']))
{
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $lname = mysqli_real_escape_string($con, $_POST['lname']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, $_POST['password']);
    $pnum = mysqli_real_escape_string($con, $_POST['pnum']);
    $conpass = mysqli_real_escape_string($con, $_POST['conpassword']);
    $user_type = mysqli_real_escape_string($con, $_POST['user_type']);


    if($pass == $conpass)
    {
        $checkemail = "SELECT email FROM user WHERE email = '$email'";
        $checkemail_run = mysqli_query($con, $checkemail);

        if(mysqli_num_rows($checkemail_run) > 0)
        {
            //Already Email Exist
            $_SESSION['message'] = "Already Email Exist";
            header("Location: register.php");
            exit(0);
        }
        else
        {

            $user_query = "INSERT INTO user (fname,lname,email,pnum,password,user_type) VALUES ('$fname','$lname','$email','$pnum','$pass','$user_type')";
            $user_query_run = mysqli_query($con, $user_query);

            if($user_query_run)
            {
                $_SESSION['message'] = "Registered Succesfully";
                header("Location: login.php");
                exit(0);
            }
            else
            {
                $_SESSION['message'] = "Something Went Wrong";
                header("Location: register.php");
                exit(0);
            }
            
        }
    }
    else
    {
        $_SESSION['message'] = "Password and Confirm Password does not Match";
        header("Location: register.php");
    }
}
else
{
    header("Location: register.php");
}
?>