<?php
session_start();
include('admin/config/dbcon.php');
include('includes/header.php');
include_once 'contactform.php'; 
?>


<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <h4 class="main-heading">Special Menu</h4>


                <div class="row">
                    <?php 
                        $tspecial_query = "SELECT * FROM product WHERE today_special='0' AND status='0'";
                        $tspecial_query_run = mysqli_query($con, $tspecial_query);

                        if($tspecial_query_run)
                        {
                            if(mysqli_num_rows($tspecial_query_run) > 0)
                            {
                                foreach($tspecial_query_run as $item)
                                {
                                    ?>
                                        <div class="col-md-3 product_data">
                                            <div class="box-card-one">
                                                <div class="box-card-body">
                                                    <div class="prod_image img-box">
                                                        <img src="upload/<?= $item['image']; ?>" alt="item image">
                                                    </div>
                                                    <div class="box-card-content">

                                                        <h3 class="box-card-title"><?= $item['name']; ?></h3>
                                                        <h4 class="box-card-price">
                                                            RM <?= $item['price']; ?>
                                                            
                                                        </h4>

                                                        <div class="divider"></div>

                                                        <div class="row">
                                                            <div class="col-md-6 col-6">
                                                                <div>
                                                                    <input type="hidden" class="prod_id" value="<?= $item['id']; ?>">
                                                                    <div class="input-group text-center">
                                                                        <button class="input-group-text decrement-btn">-</button>
                                                                        <input type="text" name="quantity" disabled class="form-control bg-white qty-input text-center" value="1" >
                                                                        <button class="input-group-text increment-btn">+</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6 col-6">
                                                                <div>
                                                                    <?php if($item['availability_status'] == '0') : ?>
                                                                        <button class="btn btn-dahlia bg-yellow w-100 addToCartBtn">Add<i class="fa fa-shopping-cart"></i></button>
                                                                    <?php else : ?>
                                                                        <button class="btn btn-dahlia bg-danger w-100 disabled"> Unavailable</button>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                }
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('pages/about-us.php'); ?>

<div class="section bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <h4 class="main-heading">Popular Menu</h4>


                <div class="row owl-carousel owl-theme trend-foods">
                    <?php 
                        $trending_query = "SELECT * FROM product WHERE trending='0' AND status='0'";
                        $trending_query_run = mysqli_query($con, $trending_query);

                        if($trending_query_run)
                        {
                            if(mysqli_num_rows($trending_query_run) > 0)
                            {
                                foreach($trending_query_run as $item)
                                {
                                    ?>
                                        <div class="item">
                                            <div class="product_data">
                                                <div class="box-card-one">
                                                    <div class="box-card-body">
                                                        
                                                        <div class="prod_image img-box">
                                                            <img src="upload/<?= $item['image']; ?>" class="w-100" alt="item image">
                                                        </div>
                                                        <div class="box-card-content">
                                                            <h3 class="box-card-title"><?= $item['name']; ?></h3>
                                                            <h4 class="box-card-price">
                                                                RM <?= $item['price']; ?>
                                                            </h4>

                                                            <div class="divider"></div>

                                                            <div class="row">
                                                                <div class="col-md-6 col-6">
                                                                    <div>
                                                                        <input type="hidden" class="prod_id" value="<?= $item['id']; ?>">
                                                                        <div class="input-group text-center">
                                                                            <button class="input-group-text decrement-btn">-</button>
                                                                            <input type="text" name="quantity" disabled class="form-control bg-white qty-input text-center" value="1" >
                                                                            <button class="input-group-text increment-btn">+</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6 col-6">
                                                                    <div>
                                                                        <?php if($item['availability_status'] == '0') : ?>
                                                                            <button class="btn btn-dahlia bg-yellow w-100 addToCartBtn">Add<i class="fa fa-shopping-cart"></i></button>
                                                                        <?php else : ?>
                                                                            <button class="btn btn-dahlia bg-danger w-100 disabled">Unavailable</button>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                }
                            }
                        }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="contact-banner">
    <div class="section contact-banner-overlay">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-md-9">
                    <h4 class="text-white main-heading">Contact Us</h4>
                    <div class="contact-content">
                    <form action="contactform.php" method="POST">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-5"><br>
                                    <label for="">Full Name</label>
                                    <input type="text" name="fullname" required class="form-control"  placeholder="Your Full Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="">Email Address</label>
                                    <input type="text" name="email" required class="form-control"  placeholder="Your Email Address">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="">Subject</label>
                                    <input type="text" name="subject" required class="form-control" placeholder="Subject">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="">Phone Number</label>
                                    <input type="tel" name="phone" required class="form-control"  placeholder="Your Phone Number">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="">Message</label>
                                    <textarea name="message" required class="form-control" rows="3" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" name="submit" class="btn btn bg-yellow py-2 px-4">Send Email</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
?>
