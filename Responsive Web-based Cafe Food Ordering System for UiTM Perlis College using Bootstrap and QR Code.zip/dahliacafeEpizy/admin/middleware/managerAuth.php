<?php
    if($_SESSION['auth_type'] != 'admin' && $_SESSION['auth_type'] != 'Manager') 
    {
        $_SESSION['message'] = "You are not Authorized as Manager/Admin to access that page";
        header("Location: orders.php");
        exit(0);
    }
?>