-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2023 at 10:51 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dahliacafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(191) NOT NULL,
  `product_id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `product_qty` int(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `user_id`, `product_qty`, `created_at`) VALUES
(45, 1, 16, 1, '2023-01-16 07:09:01');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(161) NOT NULL,
  `image` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0=visible, 1=hidden, 2=deleted',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `slug`, `image`, `status`, `created_at`) VALUES
(1, 'Masakan Panas', 'masakan-panas', 'masakan_panas.png', 0, '2022-11-23 11:15:01'),
(2, 'Sup/Tomyam/Kuah', 'sup-kuah-tomyam', '1669266216.png', 0, '2022-11-24 05:03:36'),
(3, 'Western', 'western-makanan-barat', '1669266754.png', 0, '2022-11-24 05:12:34'),
(4, 'Minuman/Beverage', 'minuman-air-beverage', '1669267569.png', 0, '2023-01-07 17:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `fullname` varchar(191) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fname` varchar(191) NOT NULL,
  `lname` varchar(191) NOT NULL,
  `pnum` varchar(191) NOT NULL,
  `no_table` int(191) NOT NULL,
  `user_message` mediumtext NOT NULL,
  `total_price` varchar(50) NOT NULL,
  `payment_id` varchar(191) NOT NULL,
  `payment_mode` varchar(191) NOT NULL,
  `payment_status` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `order_no` varchar(191) NOT NULL,
  `cancel_reason` mediumtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `fname`, `lname`, `pnum`, `no_table`, `user_message`, `total_price`, `payment_id`, `payment_mode`, `payment_status`, `status`, `order_no`, `cancel_reason`, `created_at`) VALUES
(1, 2, 'Customer', 'Test', '0134299122', 1, 'Bungkus', '5', '', 'CASH', 1, 3, 'pJoyXI3SQF', '', '2023-01-01 17:49:55'),
(2, 2, 'Customer', 'Test', '0134567891', 1, '', '5', '', 'CASH', 1, 3, '9HAmaSePLf', '', '2023-01-02 17:00:05'),
(3, 2, 'Customer', 'Test', '0134567891', 1, 'Dine in', '10', '', 'CASH', 1, 3, 'rUSLo6Anjs', '', '2023-01-03 09:32:22'),
(4, 2, 'Customer', 'Test', '0134567891', 1, '', '5', '', 'CASH', 0, 2, 'JuHAhQr3iT', 'Fhgf', '2023-01-03 09:34:30'),
(5, 2, 'Customer', 'Testing', '0134567891', 1, '', '5', '', 'CASH', 0, 2, 'S2JmlXwjF7', 'Reason', '2023-01-03 09:57:05'),
(6, 2, 'Customer', 'Testing', '0134567891', 2, '', '5', '', 'CASH', 0, 4, 'kLGwnmiMvA', 'Late', '2023-01-04 03:00:48'),
(7, 4, 'Syifa', 'Ramzi', '0125291363', 5, 'Extra chicken in my bihun sup and extra spicy in my nasi goreng kampung', '17.99', '', 'CASH', 1, 3, 'sjf8yHNnmk', '', '2023-01-06 14:10:47'),
(8, 5, 'Nur', 'Balqis', '0199878006', 1, '', '14.29', '', 'CASH', 1, 3, 'lYrg67n34D', '', '2023-01-06 14:12:53'),
(9, 3, 'Customer ', 'Testing', '0135216355', 6, 'Dine In', '1.3', '', 'CASH', 1, 3, 'OaEqAyUsHx', '', '2023-01-06 16:12:01'),
(10, 6, 'Aimunii', 'Nadhrah', '0193677008', 1, 'Saya nak sos cili lebih', '25.97', '', 'CASH', 1, 3, 'B1HfyWiVud', '', '2023-01-08 09:36:05'),
(11, 6, 'Aimuni', 'Nadhrah', '0193677008', 4, 'Dine In', '19.1', '', 'CASH', 0, 2, 'bLVOg1qRE9', '', '2023-01-09 13:19:12'),
(12, 6, 'Aimuni', 'Nadhrah', '0193677008', 6, 'Dine In', '13.98', '', 'CASH', 0, 4, 's7Z9VtNgkX', 'Unpaid', '2023-01-09 14:13:15'),
(13, 7, 'SITI AISYAH BT ', 'ASHRI', '0184640118', 1, 'tolonglah bagi sedap dooh ', '13.79', '', 'CASH', 1, 3, 'Dz3dO25MTH', '', '2023-01-10 07:33:26'),
(14, 6, 'Aimuni', 'Nadhrah', '0193677008', 3, 'Pedas', '12.49', '', 'CASH', 1, 3, 'GI48iO0cvm', '', '2023-01-10 08:40:23'),
(15, 10, 'NURUL SHAHIRAH ', 'BINTI SAMAD', '01151678821', 1, 'Take away', '3.5', '', 'CASH', 1, 3, '9XOSDvFdmM', '', '2023-01-12 09:10:56'),
(16, 12, 'Zetty', 'Adlyna', '0193178751', 1, 'Taknak kmpung', '5.5', '', 'CASH', 1, 3, 'qPBhNpkuiX', '', '2023-01-12 09:20:55'),
(17, 11, 'Anim', 'Akma', '01129838846', 1, '', '6.99', '', 'CASH', 1, 3, 'PyupQSMDYq', '', '2023-01-12 09:27:52'),
(18, 3, 'Test', ' Testing', '0135216355', 1, 'Bungkus', '5', '', 'CASH', 0, 4, 'cWjlH0vTKO', 'Test', '2023-01-12 09:34:55'),
(19, 13, 'Syida', 'Tirah', '0184694153', 1, 'Dine in', '12.49', '', 'CASH', 1, 3, 'oNfgTCMD3n', '', '2023-01-12 09:44:06'),
(20, 14, 'Nur', 'Amanina', '01124285460', 5, 'Bungkus', '6.99', '', 'CASH', 0, 2, 'I58s4kHeVu', '', '2023-01-12 09:58:58'),
(21, 15, 'Nur ', 'Masitah', '0173029713', 2, 'Take away', '5.5', '', 'CASH', 1, 3, 'YJxcIk7MlL', '', '2023-01-12 09:59:02'),
(22, 3, 'Test', ' Testing', '0135216355', 9, '', '8.5', '', 'CASH', 0, 4, 'YmQRgKdfrp', 'test', '2023-01-12 12:28:54'),
(23, 3, 'Test', ' Testing', '0135216355', 2, '', '5.5', '', 'CASH', 1, 3, '16KQyjNFpi', '', '2023-01-14 15:10:35'),
(24, 3, 'Test', ' Testing', '0135216355', 4, 'take away', '6.99', '', 'CASH', 0, 2, 'lM9goyFRjS', '', '2023-01-17 00:54:01'),
(25, 3, 'Test', ' Testing', '0134299122', 1, '', '5.5', '', 'CASH', 1, 3, 'xNs3m1RaqH', '', '2023-01-18 13:16:59'),
(26, 3, 'Test', ' Testing', '0134299122', 4, 'take_away', '10.49', '', 'CASH', 0, 4, 'Eprjh7tPcR', 'N/A', '2023-01-18 13:31:44'),
(27, 3, 'Test', ' Testing', '0134299122', 2, 'Dine In', '5.5', '', 'CASH', 1, 3, 'qyUDhK0XQH', '', '2023-01-18 13:35:06'),
(28, 3, 'Nur', ' Amirah', '0134299122', 2, 'Dine In', '6.99', '', 'CASH', 1, 3, 'Hzf2pF4Rh6', '', '2023-01-19 14:20:43'),
(29, 3, 'Nur', ' Amirah', '0134299122', 4, 'Dine In', '13.98', '', 'CASH', 0, 4, 'K7oSIseqca', 'N/A', '2023-01-19 14:26:21'),
(30, 3, 'Nur', ' Amirah', '0134299122', 1, 'Take Away', '5', '', 'CASH', 0, 4, 'h16CmrAlfM', 'N/A', '2023-01-19 14:27:04'),
(31, 3, 'Nur', ' Amirah', '0134299122', 5, 'Dine In', '6.8', '', 'CASH', 1, 3, 'mkXfsMBGOj', '', '2023-01-24 08:03:14'),
(32, 3, 'Nur', ' Amirah', '0134299122', 5, 'Dine In', '6.8', '', 'CASH', 1, 3, '3yGUXbTVgs', '', '2023-01-24 08:15:00'),
(33, 3, 'Nur', ' Amirah', '0134299122', 4, 'Dine In', '6.8', '', 'CASH', 1, 3, '2sCoShBgmx', '', '2023-01-24 08:17:55'),
(34, 3, 'Nur', ' Amirah', '0134299122', 2, 'Dine In', '6.8', '', 'CASH', 1, 3, 'bnDA6oc4qv', 'Late', '2023-01-24 08:25:08'),
(35, 3, 'Siti', ' Amirah', '0134299122', 3, 'Dine In', '5.5', '', 'CASH', 0, 4, 'cyLkT8esxf', 'N/A', '2023-01-29 14:58:55'),
(36, 3, 'Siti', ' Amirah', '0134299122', 1, 'Take Away', '8.5', '', 'CASH', 1, 3, 'lewSxgN4qd', '', '2023-01-30 09:15:07'),
(37, 3, 'Siti', ' Amirah', '0134299122', 2, 'Dine In', '12.49', '', 'CASH', 0, 4, 'Mc8EFd5NiQ', 'Test', '2023-01-30 09:49:17');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `prod_price` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `prod_id`, `prod_qty`, `prod_price`, `created_at`) VALUES
(1, 1, 1, 1, '5.00', '2023-01-01 17:49:55'),
(2, 2, 1, 1, '5.00', '2023-01-02 17:00:05'),
(3, 3, 1, 2, '5.00', '2023-01-03 09:32:22'),
(4, 4, 1, 1, '5.00', '2023-01-03 09:34:30'),
(5, 5, 1, 1, '5.00', '2023-01-03 09:57:05'),
(6, 6, 1, 1, '5.00', '2023-01-04 03:00:48'),
(7, 7, 1, 1, '5.00', '2023-01-06 14:10:47'),
(8, 7, 3, 1, '6.00', '2023-01-06 14:10:47'),
(9, 7, 2, 1, '6.99', '2023-01-06 14:10:47'),
(10, 8, 2, 1, '6.99', '2023-01-06 14:12:53'),
(11, 8, 3, 1, '6.00', '2023-01-06 14:12:53'),
(12, 8, 5, 1, '1.30', '2023-01-06 14:12:53'),
(13, 9, 5, 1, '1.30', '2023-01-06 16:12:01'),
(14, 10, 1, 1, '5.00', '2023-01-08 09:36:05'),
(15, 10, 4, 3, '6.99', '2023-01-08 09:36:05'),
(16, 11, 1, 3, '5.50', '2023-01-09 13:19:12'),
(17, 11, 6, 2, '1.30', '2023-01-09 13:19:12'),
(18, 12, 2, 2, '6.99', '2023-01-09 14:13:15'),
(19, 13, 1, 1, '5.50', '2023-01-10 07:33:26'),
(20, 13, 2, 1, '6.99', '2023-01-10 07:33:26'),
(21, 13, 6, 1, '1.30', '2023-01-10 07:33:26'),
(22, 14, 1, 1, '5.50', '2023-01-10 08:40:23'),
(23, 14, 2, 1, '6.99', '2023-01-10 08:40:23'),
(24, 15, 7, 1, '3.50', '2023-01-12 09:10:56'),
(25, 16, 1, 1, '5.50', '2023-01-12 09:20:55'),
(26, 17, 2, 1, '6.99', '2023-01-12 09:27:52'),
(27, 18, 8, 1, '5.00', '2023-01-12 09:34:55'),
(28, 19, 2, 1, '6.99', '2023-01-12 09:44:06'),
(29, 19, 1, 1, '5.50', '2023-01-12 09:44:06'),
(30, 20, 2, 1, '6.99', '2023-01-12 09:58:58'),
(31, 21, 1, 1, '5.50', '2023-01-12 09:59:02'),
(32, 22, 7, 1, '3.50', '2023-01-12 12:28:54'),
(33, 22, 8, 1, '5.00', '2023-01-12 12:28:54'),
(34, 23, 1, 1, '5.50', '2023-01-14 15:10:35'),
(35, 24, 2, 1, '6.99', '2023-01-17 00:54:01'),
(36, 25, 1, 1, '5.50', '2023-01-18 13:16:59'),
(37, 26, 2, 1, '6.99', '2023-01-18 13:31:44'),
(38, 26, 7, 1, '3.50', '2023-01-18 13:31:44'),
(39, 27, 1, 1, '5.50', '2023-01-18 13:35:06'),
(40, 28, 2, 1, '6.99', '2023-01-19 14:20:43'),
(41, 29, 2, 1, '6.99', '2023-01-19 14:26:21'),
(42, 29, 4, 1, '6.99', '2023-01-19 14:26:21'),
(43, 30, 8, 1, '5.00', '2023-01-19 14:27:04'),
(44, 31, 1, 1, '5.50', '2023-01-24 08:03:14'),
(45, 31, 6, 1, '1.30', '2023-01-24 08:03:14'),
(46, 32, 1, 1, '5.50', '2023-01-24 08:15:00'),
(47, 32, 6, 1, '1.30', '2023-01-24 08:15:00'),
(48, 33, 1, 1, '5.50', '2023-01-24 08:17:55'),
(49, 33, 6, 1, '1.30', '2023-01-24 08:17:55'),
(50, 34, 1, 1, '5.50', '2023-01-24 08:25:08'),
(51, 34, 6, 1, '1.30', '2023-01-24 08:25:08'),
(52, 35, 1, 1, '5.50', '2023-01-29 14:58:55'),
(53, 36, 6, 1, '5.00', '2023-01-30 09:15:07'),
(54, 36, 5, 1, '3.50', '2023-01-30 09:15:07'),
(55, 37, 2, 1, '6.99', '2023-01-30 09:49:17'),
(56, 37, 1, 1, '5.50', '2023-01-30 09:49:17');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category_id` int(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(161) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `today_special` tinyint(4) NOT NULL,
  `availability_status` tinyint(4) NOT NULL,
  `trending` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0=visible, 1=hidden, 2=deleted',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category_id`, `name`, `slug`, `description`, `price`, `image`, `today_special`, `availability_status`, `trending`, `status`, `created_at`) VALUES
(1, 1, 'Nasi Goreng Kampung', 'nasi-goreng-kampung-belacan', '<p>Kandungan: Nasi, Bawang Merah & Putih, Cili Padi, Sayur Kangkung, Ikan Bilis, Sos Ikan, Sos Tiram, Telur, Lada Sulah, Lobak Merah</p>', '5.50', '1675069844.jpg', 0, 0, 0, 0, '2023-01-01 17:47:51'),
(2, 3, 'Chicken Chop', 'chicken-chop-ayam', '<p>Kandungan: Ayam, Kentang, Mayo, Blackpepper, Serbuk cili/paprika, Lada putih, Mentega, Bawang holland, Sos Tiram, Sos blackpepper, Kicap manis, Kiub pati ayam, Tepung</p>', '6.99', '1675069853.jpg', 0, 0, 1, 0, '2023-01-04 08:36:39'),
(3, 2, 'Bihun Celup Thai', 'bihun-sup-thai', '<p>Kandungan: Bihun, Sawi, Kubis, Tauge, Daun sup, Limau nipis, Kacang tanah, Bawang goreng, Sambal Kicap, Emping Cili, Bawang besar, Bawang putih, Halia, Serai, Sup bunjut, Sos ikan, Kicap manis, Gula &amp; Gara, Minyak</p>', '6.00', '1675069861.jpg', 1, 0, 0, 0, '2023-01-04 08:38:52'),
(4, 3, 'Meatball', 'meatball-bebola-daging', '<p>Bahan bahan:</p>', '6.99', '1675069873.jpg', 1, 0, 0, 0, '2023-01-04 08:40:42'),
(5, 1, 'Mi Goreng', 'mi-goreng-mee', '<p>Kandungan: Mi Kuning,Udang, Telur, Fish Cake, Sayur(Sawi,Tomato,Taugeh), Cili Kisar, Sos Tiram, Kicap Manis, Garam & Gula, Bawang Putih & Merah</p>', '3.50', '1675069883.jpg', 0, 0, 1, 0, '2023-01-08 11:56:35'),
(6, 2, 'Mi Kari', 'mi-kari-mee', 'Kandungan:', '5.00', '1675069895.png', 0, 0, 0, 0, '2023-01-10 08:34:59'),
(7, 4, 'Sirap Ais', 'sirap-ais', '<p>Kandungan: Sirap kordial, gula, air, ais.</p>', '1.30', '1675070530.jpg', 1, 0, 0, 0, '2023-01-30 09:22:10'),
(8, 4, 'Te', 'te', '<p>Kandungan: Serbuk teh, Susu, Air, Garam</p>', '1.50', '1675070663.jpg', 1, 0, 0, 0, '2023-01-30 09:24:23');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(191) NOT NULL,
  `fname` varchar(191) NOT NULL,
  `lname` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `pnum` varchar(12) NOT NULL,
  `password` varchar(13) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `user_type` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `email`, `pnum`, `password`, `status`, `user_type`, `created_at`) VALUES
(1, 'Siti', 'Nadzirah', 'sitinadzirah496@gmail.com', '0135216355', 'ALQ8017n@dd98', 0, 'admin', '2022-12-31 14:01:12'),
(3, 'Siti', ' Amirah', 'customerTest@gmail.com', '0134299122', 'ALQ8017n@dd98', 0, 'user', '2023-01-04 04:47:49'),
(4, 'Syifa', 'Ramzi', 'syifapcy15@gmail.com', '0125291363', 'Flowergirl99#', 0, 'user', '2023-01-06 14:05:25'),
(5, 'Nur', 'Balqis', 'nur.balqisaz@gmail.com', '0199878006', 'Balqis5162', 0, 'user', '2023-01-06 14:07:26'),
(6, 'Aimuni', 'Nadhrah', 'aimuni@gmail.com', '0193677008', 'Aimuni_98', 0, 'user', '2023-01-08 09:32:58'),
(7, 'SITI AISYAH BT ', 'ASHRI', 'aisyahashri66@gmail.com', '0184640118', 'Madibudu123.', 0, 'user', '2023-01-10 07:30:10'),
(8, 'aizuddin ', 'danial', 'aizuddindan4@gmail.com', '0174201577', 'Sariya0%', 0, 'admin', '2023-01-10 08:29:49'),
(9, 'Nurul', 'Zahida', 'nurulzahida87@gmail.com', '0104003806', 'Dadidu@87', 0, 'cashier', '2023-01-10 08:29:56'),
(10, 'NURUL SHAHIRAH ', 'BINTI SAMAD', 'shahirahsamad3@gmail.com', '01151678821', 'Nurul.smd3', 0, 'user', '2023-01-12 09:09:24'),
(11, 'Anim', 'Akma', 'nurfarhanimakma12@gmail.com', '01129838846', 'Farhanimakma1', 0, 'user', '2023-01-12 09:19:45'),
(12, 'Zetty', 'Adlyna', 'zettyadlyna@gmail.com', '0193178751', 'Zettyadlyna00', 0, 'user', '2023-01-12 09:19:48'),
(13, 'Syida', 'Tirah', 'theqtsy@gmail.com', '0184694153', 'Sa150300', 0, 'user', '2023-01-12 09:42:13'),
(14, 'Nur', 'Amanina', 'nuramanina149@gmail.com', '01124285460', 'Aman1156@', 0, 'user', '2023-01-12 09:57:03'),
(15, 'Nur ', 'Masitah', 'masitahnordin12@gmail.com', '0173029713', 'Mashii12#_', 0, 'user', '2023-01-12 09:57:42'),
(16, 'Hafiizh', 'Razak', 'hafiizh.razak@gmail.com', '0198730540', 'Hafiizh99', 0, 'user', '2023-01-16 07:08:33'),
(17, 'Ahmad', 'Azri', 'azri@gmail.com', '0135648933', 'Ahmad@zr1', 0, 'kitchen', '2023-01-18 15:10:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
