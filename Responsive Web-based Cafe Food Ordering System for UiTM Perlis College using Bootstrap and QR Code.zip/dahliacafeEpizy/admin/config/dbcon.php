<?php

$host ="localhost";
$username ="root";
$password ="";
$database="dahliacafe";

$con = mysqli_connect($host, $username, $password, $database); 

if(!$con)
{
    //header("Location: ../errors/dberror.php");
    die("Connection Failed:".mysqli_connect_error());

}

?>
