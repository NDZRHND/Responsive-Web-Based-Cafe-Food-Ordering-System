<?php
include('authentication.php');
include('includes/header.php');

    if(!isset($_GET['order_no']))
    {
        ?>
        <h4>Something Went Wrong</h4>
        <?php
    }
    elseif(isset($_GET['order_no']))
    {
        $order_no = mysqli_real_escape_string($con,$_GET['order_no']);

        // Check tracking number is valid
        $order_query = "SELECT * FROM orders WHERE order_no='$order_no' ";
        $order_query_run = mysqli_query($con,$order_query);

        if($order_query_run)
        {
            if(!mysqli_num_rows($order_query_run) > 0)
            {
                ?>
                <h4>Something Went Wrong </h4>
                <?php
            }
            else
            {
                $data = mysqli_fetch_array($order_query_run);
            }
        }

    }
?>

    <div class="container-fluid px-4">
    <div class="message">
    <?php include('message.php');?>
    </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                <div class="card-header">
                    <h4>Order Details
                    <a href="orders.php" class="btn btn-danger float-end">
                    <i class="fa fa-reply"></i></a>
                    </h4>
                    
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-7">
                            <h5 class="heading">Details</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="fw-bold">First Name</label>
                                    <div class="">
                                    <input type="text" class="form-control" value="<?=$data['fname'] ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-bold">Last Name</label>
                                    <div class="">
                                    <input type="text" class="form-control" value="<?=$data['lname'] ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-bold">Phone Number</label>
                                    <div class="">
                                    <input type="text" class="form-control" value="<?=$data['pnum'] ?>">
                                        <!--label class=""><!?= $data['pnum'] ?></label-->
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-bold">Table No(opt.)</label>
                                    <div class="">
                                    <input type="text" class="form-control" value="<?=$data['no_table'] ?>">
                                    </div>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="fw-bold">Custom Message (opt.)</label>
                                    <div class="">
                                    <input type="text" class="form-control" value="<?=$data['user_message'] ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-5">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                        $orderview_query = "SELECT o.id as order_id, o.user_id, o.total_price, oi.order_id, oi.prod_id, oi.prod_qty, oi.prod_price, p.id as pid, p.name,p.image 
                                        FROM orders o, order_items oi, product p WHERE p.id=oi.prod_id AND oi.order_id=o.id AND o.order_no='$order_no' ";
                                        $orderview_query_run = mysqli_query($con, $orderview_query);

                                        if($orderview_query_run)
                                        {
                                            if(mysqli_num_rows($orderview_query_run) > 0)
                                            {
                                                foreach($orderview_query_run as $item)
                                                {
                                                    ?>
                                                        <tr>
                                                            <td>
                                                                <img src="../upload/<?= $item['image']; ?>" height="80px" width="80px" alt="item image">
                                                            </td>
                                                            <td><?= $item['name']; ?></td>
                                                            <td>RM <?= $item['prod_price']; ?></td>
                                                            <td><?= $item['prod_qty']; ?></td>
                                                        </tr>
                                                    <?php
                                                }
                                            }
                                            else
                                            {
                                                die("Something Went Wrong");
                                            }
                                        }
                                        else
                                        {
                                            die("Something Went Wrong");
                                        }
                                    ?>
                                </tbody>
                            </table>
                            <div class="text-end">
                                <h5 class="">Total price: RM <?= $item['total_price']; ?></h4>
                            </div>
                            <div class="mt-3">
                            <h6>Order Number : <?= $data['order_no']; ?></h6>
                                <h6>Order Status : 
                                    <?php 
                                        if($data['status'] == '0')
                                        {
                                            ?>
                                                <span class="badge bg-warning text-black">Order Accept</span>
                                            <?php
                                        }
                                        else if($data['status'] == '1')
                                        {
                                            ?>
                                                <span class="badge bg-orange text-black">Cooking</span>
                                            <?php
                                            
                                        }
                                        else if($data['status'] == '2')
                                        {
                                            ?>
                                                <span class="badge bg-celery text-black">Ready</span>
                                            <?php
                                            
                                        }
                                        else if($data['status'] == '3')
                                        {
                                            ?>
                                                <span class="badge bg-success">Completed</span>
                                            <?php
                                            
                                        }
                                        else if($data['status'] == '4')
                                        {
                                            ?>
                                                <span class="badge bg-danger mb-2">Cancelled</span>
                                                <br>
                                                Cancel Reason :
                                                <div class="border p-2 bg-light mt-1">
                                                    <?= $data['cancel_reason']; ?>
                                                </div>
                                            <?php
                                        }

                                    ?>    
                                </h6>

                                <h6>Payment Mode : <?= $data['payment_mode']; ?></h6>
                                <h6>Payment Status : <?= $data['payment_status'] =='0'?'Pending':'Paid'; ?></h6>
                                <h6>Order placed at : <?= date('d-m-Y h:i A', strtotime($data['created_at'])); ?></h6>

                                <hr>
                                <?php if($data['status'] != '4'): ?>
                                <div class="p-2">
                                    <h6 for="">Update Order Status</h6>
                                    <form action="code.php" method="POST">
                                        <input type="hidden" name="order_no" value="<?= $data['order_no']; ?>">
                                        <select class="form-select" name="order_status" aria-label="Default select example">
                                            <option value="" selected>Select status</option>
                                            <option <?= $data['status'] == '0'?'selected':''; ?> value="0">Order Accept</option>
                                            <option <?= $data['status'] == '1'?'selected':''; ?> value="1">Cooking</option>
                                            <option <?= $data['status'] == '2'?'selected':''; ?> value="2">Ready</option>
                                            <option <?= $data['status'] == '3'?'selected':''; ?> value="3">Completed</option>
                                            <option <?= $data['status'] == '4'?'selected':''; ?> value="4">Cancelled</option>
                                        </select>
                                        <h6 class="mt-3">Cancel Reason</h6>
                                        <textarea rows="3" class="form-control mb-2" name="cancel_reason"></textarea>
                                        <button name="update_order_btn" class="btn btn-dark float-end mt-3">Update</button>
                                    </form>
                                </div>
                                <?php endif; ?>

                                
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>