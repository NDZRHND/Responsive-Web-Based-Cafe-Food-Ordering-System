<?php
include('authentication.php');
include('middleware/managerAuth.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">
            <?php include('message.php');?>
            <div class="card">
                <div class="card-header">
                    <h4>Registered User</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="myTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Roles</th>
                                    <th>Active Status</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM user";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {
                                        ?>
                                        <tr>
                                            <td><?= $row['id'];?></td>
                                            <td><?= $row['fname']; ?></td>
                                            <td><?= $row['lname']; ?></td>
                                            <td><?= $row['email']; ?></td>                                   
                                            <td>
                                                <?php
                                                if($row['user_type'] == 'admin'){
                                                    echo'Admin';

                                                }elseif($row['user_type'] == 'user'){
                                                    echo 'User';

                                                }elseif($row['user_type'] == 'kitchen'){
                                                    echo 'Kitchen Crew';

                                                }else if($row['user_type'] == 'manager'){
                                                    echo 'Manager';
                                                }
                                                ?>

                                            </td>
                                            <td>
                                            <?php
                                                if($row['status'] == '0'){
                                                    echo'Active';

                                                }elseif($row['status'] == '1'){
                                                    echo 'Banned';
                                                }
                                                ?>
                                            </td>

                                            
                                            <td><a href="edit-register-user.php?id=<?= $row['id']; ?>" class="btn btn-success">Edit</a></td>
                                            <td>
                                                <form action="code.php" method="POST">
                                                <button type="submit" name="delete-register-user" value="<?= $row['id'];?>" class="btn btn-danger">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                else
                                {
                                ?>
                                    <tr>
                                        <td colspan="6">No Record Found</td>
                                    </tr>
                                <?php
                                }
                                ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>
