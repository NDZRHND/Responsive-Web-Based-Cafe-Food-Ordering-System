<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <h4 class="mt-4">Users</h4>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
            <li class="breadcrumb-item">Users</li>
            <li class="breadcrumb-item">Edit User</li>
        </ol>
    <div class="row">
    
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    <h4>Edit User
                    <a href="view-register-user.php" class="btn btn-danger float-end">BACK</a>
                    </h4>
                    
                </div>
                <div class="card-body">

                    <?php
                    if(isset($_GET['id']))
                    {
                        $user_id = $_GET['id'];
                        $user = "SELECT * FROM user WHERE id ='$user_id'";
                        $user_run = mysqli_query($con, $user);
                        

                        if(mysqli_num_rows($user_run) > 0)
                        {
                            foreach($user_run as $user)
                            {
                            ?>

                            <form action="code.php" method="POST">
                                <input type="hidden" name="user_id" value="<?=$user['id'];?>">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="">First Name</label>
                                        <input type="text" name="fname" value="<?=$user['fname']?>" class="form-control">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Last Name</label>
                                        <input type="text" name="lname" value="<?=$user['lname']?>" class="form-control">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Email Address</label>
                                        <input type="email" name="email" value="<?=$user['email']?>" class="form-control">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Phone Number</label>
                                        <input type="tel" name="pnum" value="<?=$user['pnum']?>" class="form-control">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Password</label>
                                        <input type="password" name="password" value="<?=$user['password']?>" class="form-control">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        
                                        <label for="">Role As</label>
                                            <select class="form-control" aria-label="Select" name="user_type">
                                                <option disabled selected>--Select Role--</option>
                                                <option value="admin" <?= $user['user_type'] == 'admin' ? 'selected':''; ?> >Admin</option>
                                                <option value="user" <?= $user['user_type'] == 'user' ? 'selected':''; ?> >User</option>  
                                                <option value="kitchen" <?= $user['user_type'] == 'kitchen' ? 'selected':''; ?> >Kitchen Crew</option> 
                                                <option value="manager" <?= $user['user_type'] == 'manager' ? 'selected':''; ?> >Manager</option> 
                                            </select>
                                        
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="">Status</label>
                                        <label class="switch">
                                        <input type="checkbox" role="switch" name="status" <?= $user['status'] == '1' ? 'checked':''; ?> width="70px" height="70px">
                                        <span class="slider round"></span>
                                        </label>
                                        <br>
                                        <small class="help-text">Green=Active, Red=Banned</small>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" name="update_user_data" class="btn btn-dark">Update Details</button>
                                    </div>
                                </div>
                            </form>
                        
                        <?php
                            }
                        }
                        else
                        {
                             ?>
                            <h4>No Record Found</h4>
                            <?php
                        }
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>
