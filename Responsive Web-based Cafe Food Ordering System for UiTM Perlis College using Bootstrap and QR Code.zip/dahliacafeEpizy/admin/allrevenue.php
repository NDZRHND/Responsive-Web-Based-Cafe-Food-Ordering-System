<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">

        <?php include('message.php');?>

            <div class="card">
                <div class="card-header">
                    <h4>All Revenue</h4>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-success text-white mb-4">
                                <div class="card-body">Total Earnings: </div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                <div class="card-body">
                                <?php
                                        $date = date('Y-m-d');
                                        $total_query = "SELECT SUM(total_price) as total_pay FROM orders WHERE status !='4'";
                                        $total_query_run = mysqli_query($con, $total_query);

                                        if(mysqli_num_rows($total_query_run) > 0)
                                        {
                                            $total_data = mysqli_fetch_array($total_query_run);
                                            $total_amount = $total_data['total_pay'];
                                        }

                                    ?>
                                    <h4>RM <?= $total_amount ? :"0"; ?></h4>

                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">

        <?php include('message.php');?>

            <div class="card">
                <div class="card-header">
                    <h4>Sales Report</h4>
                </div>

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                        <div class="col-md-4">
                                </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                <label for="">From Date</label>
                                    <div class="">
                                        <input type="date" name="from_date" value="<?php if(isset($_GET['from_date'])){echo $_GET['from_date'];} ?>" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                <label for="">To Date</label>
                                    <div class="">
                                        <input type="date" name="to_date" value="<?php if(isset($_GET['to_date'])){echo $_GET['to_date'];} ?>" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <br>
                                <button type="submit" class="btn btn-dark w-100">
                                    Filter <i class="fa fa-filter"></i>
                                </button>
                            </div>
                        </div>
                        <br>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                            <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Date</th>
                                        <th>Order No</th>
                                        <th>Total Price</th>
                                        
                                    </tr>
                                </thead>
                                <tbody id="reporttable">
                                    <?php

                                    if(isset($_GET['from_date']) && isset($_GET['to_date']))
                                    {
                                        $from_date = $_GET['from_date'];
                                        $to_date = $_GET['to_date'];

                                        $report_query = "SELECT id, order_no, total_price, created_at FROM orders WHERE status != '4' AND created_at BETWEEN '$from_date' AND '$to_date'";
                                        $report_query_run = mysqli_query($con, $report_query);

                                        if(mysqli_num_rows($report_query_run) > 0)
                                        {
                                            foreach($report_query_run as $row)
                                            {
                                                ?>
                                                <tr>
                                                <td><?= $row['id']; ?></td>
                                                <td><?= $row['created_at']; ?></td>
                                                <td><?= $row['order_no']; ?></td>
                                                <td>RM <?= $row['total_price']; ?></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record Found";
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <div class="col-md-2">
                                <div class="mt-4">
                                    <div class="text-end">
                                    <button onclick="window.print()" class="btn btn-dark btn-block float-right w-100">Print</button>
                                    </div>
                                </div> 
                            </div>
                        </div>
                        

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>