<?php
include('authentication.php');

$prod_id = $_GET['id'];
$query = "DELETE FROM product WHERE id='$prod_id' ";
$query_run = mysqli_query($con, $query);

if($query_run)
{
    $_SESSION['message'] = "Product Deleted Successfully";
    header('Location: products.php');
}
?>

