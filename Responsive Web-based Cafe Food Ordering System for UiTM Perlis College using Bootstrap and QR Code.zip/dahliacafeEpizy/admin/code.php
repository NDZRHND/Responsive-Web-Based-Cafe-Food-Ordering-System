<?php
include('config/dbcon.php');
include('authentication.php');


/*Add menu category*/
if(isset($_POST['add_category_btn']))
{
    // Check if image is not null
    if($_FILES['image']['name'] != '')
    {

    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $visibility = isset($_POST['visibility'])?'1':'0'; //status = visibility

    $imagename = $_FILES['image']['name'];
    $allowed_exttension = array('gif', 'png','webp', 'jpg', 'jpeg');
    $image_extension = pathinfo($imagename, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension;

    if (!in_array($image_extension, $allowed_exttension)) 
        {
            //redirect("addcategory.php","You can add only jpg, png, webp, jpeg and gif files");
            $_SESSION['message'] = "You can add only jpg, png,webp, jpeg and gif files";
            header('Location: add-category.php');
            exit(0);
        }
        else
        {
            // Insert the category data
            $query = "INSERT INTO category (name,slug,image,status) VALUES ('$name','$slug','$filename','$visibility')";
            $add_query_run = mysqli_query($con, $query);

            if($add_query_run)
            {
                // Move the image to uploads folder
                move_uploaded_file($_FILES["image"]["tmp_name"], "../upload/".$filename);
                $_SESSION['message'] = "Category Added Successfully";
                header('Location: add-category.php');
                exit(0);

            }
            else
            {
                //redirect("add-category.php","Something went Wrong");
                //echo "<script>alert('Something Went Wrong'); window.location='add-category.php';</script>";
                $_SESSION['message'] = "Something Went Wrong";
                header('Location: add-category.php');
                exit(0);
            }
        }
    }
    else
    {
        //redirect("add-category.php","Image field cannot be empty");
        $_SESSION['message'] = "Image field cannot be empty";
        header('Location: add-category.php');
        exit(0);    
    }

}
/*Update menu category*/
else if(isset($_POST['edit_category_btn']))
{
    $category_id = $_POST['category_id']; 
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $visibility = isset($_POST['visibility'])?'1':'0'; //status = visibility
    // $trending = isset($_POST['trending'])?'1':'0';
    $new_image = $_FILES['image']['name'];
    $old_image = $_POST['image_old'];

    if($new_image != '')
    {
        $filename = $new_image;
        $allowed_exttension = array('gif', 'png', 'webp','jpg', 'jpeg');
        $filename = $_FILES['image']['name'];
        $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
        if (!in_array($file_extension, $allowed_exttension)) 
        {
            
            $_SESSION['message'] = "You can add only jpg, png,webp, jpeg and gif files";
            header('Location: edit-category.php?id='.$category_id);
            exit(0);
        }
    }
    else
    {
        $filename = $old_image;
    }

    //Update category details
    $update_query = "UPDATE category SET name='$name', slug='$slug', image='$filename', status='$visibility' WHERE id='$category_id'";
    
    if(!mysqli_query($con, $update_query)) {
        //echo "<script>alert('Something Went Wrong'); window.location='category.php';</script>";
        $_SESSION['message'] = "Something Went Wrongy";
        header('Location: category.php');
        exit(0);
    }

    if($new_image !='')
    {
        move_uploaded_file($_FILES["image"]["tmp_name"], "../upload/".$_FILES["image"]["name"]);
        unlink("../upload/".$old_image);
    }

    //redirect("category.php", "Data Updated Successfully");
    // echo "<script>alert('Data Updated Successfully'); window.location='category.php';</script>";
    $_SESSION['message'] = "Data Updated Successfullyy";
    header('Location: category.php');
    exit(0);
    
    

}
/*Delete menu category*/
else if(isset($_POST['delete-category']))
{
    $category_id = $_POST['delete-category'];

    $delete_query = "UPDATE category SET status='2' WHERE id='$category_id' LIMIT 1";
    $query_run = mysqli_query($con, $delete_query);

    if($query_run)
    {
        $_SESSION['message'] = "Category Deleted Successfully";
        header('Location: category.php');
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something Went Wrong";
        header('Location: category.php');
        exit(0);
    }

}
/*Add Product*/
else if(isset($_POST['add_product_btn']))
{
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $visibility = isset($_POST['visibility'])?'1':'0'; //status = visibility
    $trending = isset($_POST['trending'])?'1':'0';
    $today_special = isset($_POST['today_special'])?'1':'0';
    $availability_status = isset($_POST['availability_status'])?'1':'0';

    $imagename = $_FILES['image']['name'];
    $allowed_exttension = array('gif', 'png','webp', 'jpg', 'jpeg');
    $image_extension = pathinfo($imagename, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_extension;

    if(!in_array($image_extension, $allowed_exttension))
    {
        
        $_SESSION['message'] = "You can add only jpg, png,webp, jpeg and gif files";
        header('Location: add-products.php');
        exit(0);
    }
    else
    {
        $add_product_query = "INSERT INTO product (category_id, name, slug, price, description, image, today_special, availability_status, trending, status)
        VALUES ('$category_id', '$name','$slug','$price','$description','$filename','$today_special','$availability_status','$trending','$visibility') ";
        
        $add_product_run = mysqli_query($con, $add_product_query);

        if($add_product_run)
        {
            // Move the image to uploads folder
            move_uploaded_file($_FILES["image"]["tmp_name"], "../upload/".$filename);
            $_SESSION['message'] = "Product Added Successfully";
            header('Location: add-products.php');
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Something Went Wrong";
            header('Location: add-products.php');
            exit(0);
        }
    }

}
/*Edit/Update Menu Products*/
else if(isset($_POST['edit_product_btn']))
{
    $prod_id = $_POST['id'];

    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $visibility = isset($_POST['visibility'])?'1':'0'; //status = visibility
    $trending = isset($_POST['trending'])?'1':'0';
    $today_special = isset($_POST['today_special'])?'1':'0';
    $availability_status = isset($_POST['availability_status'])?'1':'0';
    $old_image = $_POST['image_old'];

    if($_FILES['image']['name'] != '')
    {
        $filename = $new_image;
        $imagename = $_FILES['image']['name'];
        $allowed_exttension = array('gif', 'png','webp', 'jpg', 'jpeg');
        $image_extension = pathinfo($imagename, PATHINFO_EXTENSION);
        $filename = time().'.'.$image_extension;

        if(!in_array($image_extension, $allowed_exttension))
        {
            //redirect("edit-product.php?id=".$product_id,"You can add only jpg, png, webp, jpeg and gif files");
            $_SESSION['message'] = "You can add only jpg, png,webp, jpeg and gif files";
            header('Location: edit-products.php?id='.$prod_id);
            exit(0);
        }  
    }
    else
    {
        $filename = $old_image;
    }
        if(empty($category_id) || empty($name) || empty($slug) || empty($price) || empty($description))
        {
            $_SESSION['message'] = "All fields are required";
            header('Location: edit-product.php?id='.$prod_id);
            exit(0);
        }
        else
        {

        // Update the product data
        $update_query = "UPDATE product SET category_id='$category_id', name='$name', slug='$slug',description='$description',price='$price', image='$filename', today_special='$today_special',availability_status='$availability_status', trending='$trending',
        status='$visibility' WHERE id='$prod_id' ";
        $update_query_run = mysqli_query($con, $update_query);

        if($update_query_run)
        {
            if($imagename !='')
            {
                // Move the image to uploads folder
                move_uploaded_file($_FILES["image"]["tmp_name"], "../upload/".$filename);
                unlink("../upload/".$old_image);
            }
            
                //redirect("edit-product.php?id=".$product_id,"Product Updated Successfully");
                $_SESSION['message'] = "Product Updated Successfully";
                header('Location: products.php?id='.$prod_id);
                exit(0);
        }
        else
        {
            //redirect("addproduct.php","Something went Wrong");
            $_SESSION['message'] = "Something went Wrong";
            header('Location: add-products.php');
            exit(0);
        }
    }
}
// Update Order status
else if(isset($_POST['update_order_btn']))
{
    $order_status = $_POST['order_status'];
    $order_no = $_POST['order_no'];
    $cancel_reason = $_POST['cancel_reason'];

    if($order_status == '4' && $cancel_reason == '')
    {
        $_SESSION['message'] = "To Cancel Order, Please specify the cancel reason";
        header('Location: orders-view.php?order_no='.$order_no);
        die();
    }
    else if($order_status == '4')
    {

        $order_query = "SELECT * FROM orders WHERE order_no='$order_no' ";
        $order_query_run = mysqli_query($con,$order_query);

        if(mysqli_num_rows($order_query_run) > 0)
        {
            $update_order_query = "UPDATE orders SET status='$order_status', cancel_reason='$cancel_reason' WHERE order_no='$order_no' ";
            $update_order_query_run = mysqli_query($con, $update_order_query);

            if($update_order_query_run)
            {
                $_SESSION['message'] = "Order Status Updated Successfully";
                header('Location: orders-view.php?order_no='.$order_no);
            }
            else
            {
                $_SESSION['message'] = "Something Went Wrong";
                header('Location: orders-view.php?order_no='.$order_no);
            }
        }
        else
        {
            $_SESSION['message'] = "Something Went Wrong";
            header('Location: orders-view.php?order_no='.$order_no);
        }
    }
    else if($order_status == '1' || $order_status =='2')
    {

        $order_query = "SELECT * FROM orders WHERE order_no='$order_no' ";
        $order_query_run = mysqli_query($con,$order_query);

        if(mysqli_num_rows($order_query_run) > 0)
        {
            $update_order_query = "UPDATE orders SET status='$order_status', cancel_reason='$cancel_reason' WHERE order_no='$order_no' ";
            $update_order_query_run = mysqli_query($con, $update_order_query);

            if($update_order_query_run)
            {
                $_SESSION['message'] = "Order Status Updated Successfully";
                header('Location: orders-view.php?order_no='.$order_no);
            }
            else
            {
                $_SESSION['message'] = "Something Went Wrong";
                header('Location: orders-view.php?order_no='.$order_no);
            }
        }
        else
        {
            $_SESSION['message'] = "Something Went Wrong";
            header('Location: orders-view.php?order_no='.$order_no);
        }
    }
    else if($order_status == '3')
    {
        // While updating an order status to "Completed", We will check the order's payment_mode.
        // If it is an online payment, the payment_status will already be 1. For COD orders, We will update 
        // the payment Status to 1 after the order is completed and cash is received from the customer 

        $order_query = "SELECT * FROM orders WHERE order_no='$order_no' ";
        $order_query_run = mysqli_query($con,$order_query);

        $order_data = mysqli_fetch_array($order_query_run);
        
        if($order_data['payment_mode'] == 'CASH')
        {
            // Update payment status
            $update_payment_query = "UPDATE orders SET payment_status='1' WHERE order_no='$order_no'";
            $update_payment_query_run = mysqli_query($con,$update_payment_query);
        }

        $update_order_query = "UPDATE orders SET status='$order_status', cancel_reason='$cancel_reason' WHERE order_no='$order_no' ";
        $update_order_query_run = mysqli_query($con, $update_order_query);

        if($update_order_query_run)
        {
            $_SESSION['message'] = "Order Status Updated Successfully";
            header('Location: orders-view.php?order_no='.$order_no);
            
        }
        else
        {
            $_SESSION['message'] = "Something Went Wrong";
            header('Location: orders-view.php?order_no='.$order_no);
            
        }
    }

    header('Location: orders-view.php?order_no='.$order_no);
    die();
}
/*update registered user details*/
else if(isset($_POST['update_user_data']))
{
    $user_id = $_POST['user_id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $pnum = $_POST['pnum'];
    $pass = $_POST['password'];
    $user_type = $_POST['user_type'];
    $status = $_POST['status'] == true ? '1' : '0';

    $query = "UPDATE user SET fname='$fname', lname='$lname', email='$email', pnum='$pnum', password='$pass', user_type='$user_type', status='$status'
    WHERE id='$user_id'";

    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header('Location: view-register-user.php');
        exit(0);
    }
}
/*delete registered user*/
else if(isset($_POST['delete-register-user']))
{
    $user_id = $_POST['delete-register-user'];

    $query = "DELETE FROM user WHERE id='$user_id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Admin/User Deleted Successfully";
        header('Location: view-register-user.php');
        exit(0);
    }

    else
    {
        $_SESSION['message'] = "Something Went Wrong";
        header('Location: view-register-user.php');
        exit(0);
    }

}
else
{
    header("Location: index.php");
    exit(0);
}

?>