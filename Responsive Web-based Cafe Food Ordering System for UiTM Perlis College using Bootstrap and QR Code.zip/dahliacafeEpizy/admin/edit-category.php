<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">

        <?php include('message.php');?>

            <div class="card">
                <div class="card-header">
                    <h4>Edit Menu Categories
                    <a href="category.php" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>

                <div class="card-body">

                    <?php  
                        $category_id = $_GET['id'];
                        $category_edit = "SELECT * FROM category WHERE id='$category_id'";
                        $category_run = mysqli_query($con, $category_edit);
                    

                        if(mysqli_num_rows($category_run) > 0)
                        {
                            $category = mysqli_fetch_array($category_run);
                            ?>

                            <form action="code.php" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                        <input type="hidden" name="category_id" value="<?= $category['id']; ?>">
                                            <label class="form-label">Name</label>
                                            <input type="text" required class="form-control" name="name" value="<?=$category['name'];?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                        <label class="form-label">Slug</label>
                                        <input type="text" required class="form-control" name="slug" value="<?=$category['slug'];?>">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">Add Category Image</label>
                                            <input type="file" class="form-control" name="image">
                                                <div class="mt-3">
                                                    <label class="">Current image</label>
                                                    <input type="hidden" name="image_old" value="<?= $category['image']; ?>">
                                                    <img src="../upload/<?= $category['image']; ?>" width="70px" height="70px" alt="">
                                                </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Show/Hide</label> <br>
                                            <label class="switch">
                                                <input type="checkbox" <?php echo $category['status'] == '0'?'':'checked'; ?> name="visibility">
                                                <span class="slider round"></span>
                                            </label>
                                            <small class="help-text">Green=Shown, Red=Hidden</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="mt-4">
                                            <div class="text-end">
                                            <button type="submit" name="edit_category_btn" class="btn btn-dark btn-block float-right">Update Category</button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </form>

                            <?php  
                        }
                        else
                        {
                            echo "No Record Found";
                        }
                        
                     ?>    
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>