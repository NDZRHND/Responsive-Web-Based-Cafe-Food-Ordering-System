</main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Dahlia Cafeteria 2022. All Right Reserved.</div>
                            
                        </div>
                    </div>
                </footer>

                

                </div>
        </div>



        