<?php
include('authentication.php');
include('middleware/managerAuth.php');
include('includes/header.php');
?>


<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">

        <?php include('message.php');?>

            <div class="card">
                <div class="card-header">
                    <h4>All Product</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="myTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Visibility</th>
                                    <th>Trending</th>
                                    <th>Today's Special</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $product = "SELECT p. *, c.name AS cname FROM product p,category c WHERE c.id = p.category_id";
                                    $product_run = mysqli_query($con, $product);

                                    if(mysqli_num_rows($product_run) > 0)
                                    {
                                        foreach($product_run as $prod)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $prod['id']?></td>
                                                <td><?= $prod['cname']?></td>
                                                <td><?= $prod['name']?></td>
                                                <td>
                                                <img src="../upload/<?= $prod['image']; ?>" alt="Product image" width="60px" height="50px">
                                                </td>
                                                <td>
                                                    <?php
                                                        if($prod['status'] == '0')
                                                        {
                                                            echo '<span class="bg-success badge badge-pill text-white">Visible</span>';
                                                        }
                                                        else
                                                        {
                                                            echo '<span class="bg-danger badge badge-pill text-black">Hidden</span>';
                                                        }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                        if($prod['trending'] == '0')
                                                        {
                                                            echo '<span class="bg-success badge badge-pill text-white">Yes</span>';
                                                        }else
                                                        {
                                                            echo '<span class="bg-secondary badge badge-pill text-white">No</span>';
                                                        } 
                                                    ?>
                                                </td>
                                                <td>
                                                <?php
                                                    if($prod['today_special'] == '0')
                                                    {
                                                        echo '<span class="bg-success badge badge-pill text-white">Yes</span>';
                                                    }
                                                    else
                                                    {
                                                        echo '<span class="bg-secondary badge badge-pill text-white">No</span>';
                                                    }
                                                ?>
                                                </td>
                                                <td><a href="edit-products.php?id=<?= $prod['id'] ?>" class="btn btn-success">Edit</a></td>
                                                <td><a href="delete-products.php?id=<?= $prod['id'] ?>" class="btn btn-danger">Delete</a></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                    ?>
                                        <tr>
                                            <td colspan="9">No Record Found</td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>