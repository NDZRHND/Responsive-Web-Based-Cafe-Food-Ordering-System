<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">


            <div class="card">
                <div class="card-header">
                    <h4>Today's Revenue</h4>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-warning text-black mb-4">
                                <div class="card-body">Total Earnings: </div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                <div class="card-body">
                                <?php
                                        $date = date('Y-m-d');
                                        $total_query = "SELECT SUM(total_price) as total_pay FROM orders WHERE status != '4' AND created_at like '$date%'";
                                        $total_query_run = mysqli_query($con, $total_query);

                                        if(mysqli_num_rows($total_query_run) > 0)
                                        {
                                            $total_data = mysqli_fetch_array($total_query_run);
                                            $total_amount = $total_data['total_pay'];
                                        }

                                    ?>
                                    <h4>RM <?= $total_amount ? :"0"; ?></h4>
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>