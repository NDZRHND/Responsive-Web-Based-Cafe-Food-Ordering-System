
<?php
include('authentication.php'); 
include('middleware/managerAuth.php');
include("includes/header.php"); 
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">
        <div class="message">
        <?php include('message.php');?>
        </div>
            <div class="card">
                <div class="card-header">
                    <h4>All Category</h4>
                </div>
                <div class="card-body">
 
                    <div class="table-responsive">
                        <table class="table table-bordered" id="myTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $category = "SELECT * FROM category WHERE status!='2'";
                                $category_run = mysqli_query($con, $category);

                                if(mysqli_num_rows($category_run) > 0)
                                {
                                    foreach($category_run as $row)
                                    {
                                        ?>
                                        <tr>
                                            <td><?= $row['id']?></td>
                                            <td><?= $row['name']?></td>
                                            <td>
                                                <img src="../upload/<?= $row['image']; ?>" alt="category image" width="70px" height="60px">
                                            </td>
                                            <td>
                                                <?php
                                                    if($row['status'] == '0')
                                                    {
                                                        echo '<span class="bg-success badge badge-pill text-white">Available</span>';
                                                    }else
                                                    {
                                                        echo '<span class="bg-secondary badge badge-pill text-white">Unavailable</span>';
                                                    }
                                                    ?>
                                            </td>
                                            <td>
                                                <a href="edit-category.php?id=<?= $row['id'] ?>" class="btn btn-success">Edit</a>
                                            </td>
                                            <td>
                                                <form action="code.php" method="POST">
                                                <button type="submit" name="delete-category" value="<?= $row['id'] ?>" class="btn btn-danger">Delete</button>
                                                </form>
                                            </td>
                                            
                                        </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                ?>
                                    <tr>
                                        <td colspan="7">No Record Found</td>
                                    </tr>

                                <?php
                            }
                        ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
include("includes/scripts.php"); 
?>

