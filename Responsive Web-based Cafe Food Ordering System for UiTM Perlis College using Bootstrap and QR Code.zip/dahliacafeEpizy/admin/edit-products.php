<?php
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-md-12">

        <?php include('message.php');?>

            <div class="card">
                <div class="card-header">
                    <h4>Edit Menu Product
                    <a href="products.php" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>

                <div class="card-body">
                    <?php
                        if(isset($_GET['id']))
                        {
                            $prod_id = $_GET['id'];
                            $prod_query = "SELECT * FROM product WHERE id='$prod_id' LIMIT 1";
                            $prod_query_res = mysqli_query($con, $prod_query);

                            if(mysqli_num_rows($prod_query_res) > 0)
                            {
                                $prod_row = mysqli_fetch_array($prod_query_res);
                                ?>
                                
                            <form action="code.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $prod_row['id']?>">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                <label class="form-label">Menu Category</label>
                                    <?php
                                        $category = "SELECT * FROM category WHERE status='0'";
                                        $category_run = mysqli_query($con, $category);

                                        if(mysqli_num_rows($category_run) > 0)
                                        {
                                            ?>
                                            <select name="category_id" class="form-select" aria-label="Default select example" name="category_id">
                                            <option disabled selected>-- Choose Category --</option>
                                                <?php
                                                    foreach($category_run as $category_item)
                                                    {
                                                        ?>
                                                            <option value="<?= $category_item['id'] ?>" <?= $category_item['id'] ==  $prod_row['category_id'] ? 'selected':'' ?>>
                                                            <?= $category_item['name'] ?></option>
                                                        <?php
                                                    }
                                                ?>
                                            </select>
                                            <?php
                                        }
                                        else
                                        {
                                            ?>
                                            <h4>No Category Available</h4>
                                            <?php
                                        }
                                ?>
                            </div>             
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" required class="form-control" name="name" value="<?= $prod_row['name']?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Slug</label>
                                        <input type="text" required value="<?= $prod_row['slug']; ?>" class="form-control" name="slug">
                                    </div>
                                </div>
                           

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Add Category Image</label>
                                    <input type="file" class="form-control" name="image">
                                    <div class="mt-3">
                                        <label class="">Current image</label>
                                        <input type="hidden" name="image_old" value="<?= $prod_row['image']; ?>">
                                        <img src="../upload/<?= $prod_row['image']; ?>" width="70px" height="70px" alt="">
                                    </div>
                                </div>
                            </div>
                                <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Price</label>
                                    <input type="text" required class="form-control" name="price" value="<?= $prod_row['price']?>">
                                </div>
                            </div>


                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea name="description"  id="summernote" required class="form-control" rows="4"><?= $prod_row['description']?></textarea>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label class="form-label">Show/Hide</label> <br>
                                    <label class="switch">
                                        <input type="checkbox"  <?php echo $prod_row['status'] == '0'?'':'checked'; ?> name="visibility">
                                        <span class="slider round"></span>
                                    </label>
                                    <small class="help-text">Green=Shown, Red=Hidden</small>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label class="form-label">Trending</label> <br>
                                    <label class="switch">
                                        <input type="checkbox"  <?php echo $prod_row['trending'] == '0'?'':'checked'; ?> name="trending">
                                        <span class="slider round"></span>
                                    </label>
                                    <small class="help-text">Green=Trending, Red=Default</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label class="form-label">Today's Special</label> <br>
                                    <label class="switch">
                                        <input type="checkbox"  <?php echo $prod_row['today_special'] == '0'?'':'checked'; ?> name="today_special">
                                        <span class="slider round"></span>
                                    </label>
                                    <small class="help-text">Green=Special, Red=Default</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label class="form-label">Availability Status</label> <br>
                                    <label class="switch">
                                        <input type="checkbox"  <?php echo $prod_row['availability_status'] == '1'?'checked':''; ?> name="availability_status">
                                        <span class="slider round"></span>
                                    </label>
                                    <small class="help-text">Green=Available, Red=Unavailable</small>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mt-4">
                                    <div class="text-first">
                                    <button type="submit" name="edit_product_btn" class="btn btn-dark btn-block float-right">Update Product</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                                <?php
                            }
                            else
                            {
                                ?>
                                <h4>No Record Found</h4>
                                <?php
                            }
                        }
                    ?>
                    
                </div>

            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>