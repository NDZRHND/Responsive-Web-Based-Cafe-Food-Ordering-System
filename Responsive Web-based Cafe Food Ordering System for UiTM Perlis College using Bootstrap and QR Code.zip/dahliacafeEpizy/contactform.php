<?php 
include('admin/config/dbcon.php');

if(isset($_POST['submit']))
{
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    $query = "INSERT INTO contact (fullname, email, subject, phone, message) VALUES ('$fullname','$email','$subject','$phone','$message')";
    $query_run = mysqli_query($con, $query);

    if($query)
    {
        echo "<script>
        alert('Thankyou, we will get back to you as soon as possible');
        window.location.href='index.php';  
        </script>";
    }
    else{
        echo "<script>
        alert('Something Went Wrong');
        window.location.href='index.php';  
        </script>";
    }
    
}
?>