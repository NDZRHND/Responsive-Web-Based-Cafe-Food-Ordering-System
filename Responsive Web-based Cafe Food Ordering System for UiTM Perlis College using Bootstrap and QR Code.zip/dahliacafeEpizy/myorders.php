<?php
    include('functions/authentication.php');
    include('includes/header.php');
?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <h4 class="main-heading">My Orders</h4>
                
                <?php 
                    $user_id = $_SESSION['auth_user']['user_id'];
                    $orders_query = "SELECT * FROM orders WHERE user_id='$user_id' ORDER BY id DESC";
                    $orders_query_run = mysqli_query($con, $orders_query);

                    if($orders_query_run)
                    {
                        if(mysqli_num_rows($orders_query_run) > 0)
                        {
                            foreach($orders_query_run as $row)
                            {
                                ?>

                                    <div class="cart-page-section">
                                        <div class="row product_data">
                                            <div class="col-md-3 mbrdr my-auto">
                                                <h6 class="fw-bold mb-0 mb-md-1">Order No:</h6>
                                                <label class=""><?= $row['order_no']; ?></label>
                                            </div>
                                            <div class="col-md-2 mbrdr my-auto">
                                                <h6 class="fw-bold mb-0 mb-md-1">Price:</h6>
                                                <label class="">RM <?= $row['total_price']; ?></label>
                                            </div>
                                            <div class="col-md-3 mbrdr my-auto">
                                                <h6 class="fw-bold mb-0 mb-md-1">Order Placed at:</h6>
                                                <label class=""><?=  date('d-m-Y h:i A', strtotime($row['created_at'])); ?></label>
                                            </div>
                                            <div class="col-md-3 mbrdr my-auto">
                                                <h6 class="fw-bold mb-0 mb-md-1">Status:</h6>
                                                <?php if($row['status'] == '0') : ?>
                                                    <span class="badge bg-warning text-black">Order has been accepted</span>
                                                <?php elseif($row['status'] == '1') : ?>
                                                    <span class="badge bg-orange text-black">Order is being cooked</span>
                                                <?php elseif($row['status'] == '2') : ?>
                                                    <span class="badge bg-celery text-black">Order is ready.<br>Please make a payment at the counter.</span>
                                                <?php elseif($row['status'] == '3') : ?>
                                                    <span class="badge bg-success text-white">Completed Order</span>
                                                <?php elseif($row['status'] == '4') : ?>
                                                    <span class="badge bg-danger">Cancelled</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-1 mbrdr my-auto">
                                                <h6 class="fw-bold mb-0 mb-md-1">Action</h6>
                                                <a href="vieworder.php?no=<?=$row['order_no'];?>" class="btn btn-dahlia bg-yellow">View</a>    
                                            </div>
                                        </div>
                                    </div>

                                <?php
                            }
                        }
                        else
                        {
                            ?>
                            <tr>
                                <td colspan="4" class="text-center">
                                    You have not placed any orders!!
                                </td>
                            </tr>
                        <?php
                        }
                    }
                    else
                    {
                        die("Something Went Wrong");
                    }
                ?>
                     
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
?>
