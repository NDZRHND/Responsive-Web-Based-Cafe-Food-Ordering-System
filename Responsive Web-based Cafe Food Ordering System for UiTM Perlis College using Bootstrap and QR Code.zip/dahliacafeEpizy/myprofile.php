<?php
    include('functions/authentication.php');
    include('includes/header.php');
?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <h4 class="main-heading">My Profile</h4>
                <div class="mb-3"></div>
                <?php 
                    $user_id = $_SESSION['auth_user']['user_id'];
                    $user_query = "SELECT * FROM user WHERE id='$user_id' ";
                    $user_query_run = mysqli_query($con, $user_query);

                    if($user_query_run)
                    {
                        $user = mysqli_fetch_array($user_query_run);
                        
                        ?>
                            <div class="">
                                <form action="allcode.php" method="POST">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="">First Name</label>
                                            <input type="text" name="fname" class="form-control" value="<?= $user['fname'] ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Last Name</label>
                                            <input type="text" name="lname" class="form-control" value="<?= $user['lname'] ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Email</label>
                                            <input type="text" readonly name="email" class="form-control" value="<?= $user['email'] ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Contact Number</label>
                                            <input type="tel" name="pnum" class="form-control" value="<?= $user['pnum'] ?>">
                                        </div>
                                    </div>
                                    <div class="text-end">
                                        <button class="btn btn-dahlia px-4 py-2 btn-primary" name="update_user_details">Update Details</button>
                                    </div>
                                </form>
                            </div>
                        <?php
                    }
                ?>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/footer.php');
?>
