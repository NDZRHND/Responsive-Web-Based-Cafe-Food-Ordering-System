<?php
session_start();
if(!isset($_SESSION['auth']))
{
    $_SESSION['message'] = "Please login to continue";
    header('Location: login.php');
    exit(0);
}

?>