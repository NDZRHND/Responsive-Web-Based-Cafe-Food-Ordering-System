E-Dahlia Cafe System: dahliacafe.epizy.com

Admin: sitinadzirah496@gmail.com
Password: ALQ8017n@dd98

Cashier: nurulzahida87@gmail.com
Password: Dadidu@87

Kitchen: azri@gmail.com
Password: Ahmad@zr1