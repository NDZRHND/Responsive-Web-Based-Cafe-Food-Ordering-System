<div class="about">
    <div class="container">
        <div class="about-content">
            <h4 class="heading text-center">E-Menu is a digital menu that provide list of food and drinks by Dahlia Cafeteria in UiTM Arau, Perlis</h4>
            <p class="text-black text-center">
            Step to Order With Us:<br><br>
            1. Log in your account. Register your account before sign in.<br>
            2. Browse our menu or choose menu by Categories provided.<br>
            3. Add your food/drink into cart and place your order.<br>
            4. Once your order completed, please pay your food at the counter.
            </ul><br>     
        </div>
    </div>
</div>