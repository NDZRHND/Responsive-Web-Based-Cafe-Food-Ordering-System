<?php
session_start();
include('includes/header.php');

?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mb-3">
                    <h4 class="main-heading">About Dahlia Cafeteria</h4>
  
                </div>
                <p style="text-align: justify">
                Dahlia Cafeteria was established when there was UiTM Arau Branch, Perlis located in UiTM Arau Branch, Arau Campus, 02600 Arau, Perlis.
                This cafeteria is under the management of UiTM managed by the Unit Pengurusan Ruang Niaga. The unit is in charge of overseeing this cafeteria on behalf of UiTM.
                As the Senior College Assistant Manager, Mrs. Siti Sabariah Binti Abdullah is one of the officers of the Unit Pengurusan Ruang Niaga who has been responsible to make sure the efficient business operation of the Dahlia Cafeteria.
                </p>       
            </div>
           
        </div>
    </div>
</div>

<?php 
include('pages/about-us.php'); 
include('includes/footer.php');
?>
